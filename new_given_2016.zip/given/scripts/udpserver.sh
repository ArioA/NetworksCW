#!/bin/bash
java -cp .:udp udp.UDPServer $*
