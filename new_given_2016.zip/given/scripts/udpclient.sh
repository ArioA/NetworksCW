#!/bin/bash
java -cp .:udp udp.UDPClient $*
